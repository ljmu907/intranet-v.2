<?php
session_start();
include_once("../includes/db.php");

// 로그인 안 한 경우 로그인 페이지로
if (!isset($_SESSION["user_id"])) {
    header("Location: /login/login.html");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_pw = $_POST["new_pw"] ?? '';
    $confirm_pw = $_POST["confirm_pw"] ?? '';

    if ($new_pw !== $confirm_pw) {
        echo "<script>alert('비밀번호가 일치하지 않습니다.'); history.back();</script>";
        exit;
    }

    $user_id = $_SESSION["user_id"];
    $hashed_pw = password_hash($new_pw, PASSWORD_DEFAULT);

    $stmt = $db->prepare("UPDATE users SET password = :password, is_default_pw = 0 WHERE id = :id");
    $stmt->bindValue(':password', $hashed_pw, SQLITE3_TEXT);
    $stmt->bindValue(':id', $user_id, SQLITE3_INTEGER);
    $stmt->execute();

    // 세션 값도 갱신
    $_SESSION["is_default_pw"] = 0;

    echo "<script>alert('비밀번호가 성공적으로 변경되었습니다.'); location.href='/admin/dashboard.html';</script>";
    exit;
}
?>
