<?php
session_start();
include_once("../../includes/db.php");

// 로그인 & 권한 확인
if (!isset($_SESSION["auth_level"]) || !in_array($_SESSION["auth_level"], ["admin", "superadmin"])) {
    http_response_code(403);
    echo "권한이 없습니다.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"] ?? '';
    $name = $_POST["name"] ?? '';
    $position = $_POST["position"] ?? '';
    $department = $_POST["department"] ?? '';

    // 기본 비밀번호
    $default_pw = password_hash("nex!1001", PASSWORD_DEFAULT);

    // 중복 방지
    $check = $db->prepare("SELECT id FROM users WHERE username = :username");
    $check->bindValue(":username", $username, SQLITE3_TEXT);
    $exists = $check->execute()->fetchArray();
    if ($exists) {
        echo "<script>alert('이미 존재하는 아이디입니다.'); history.back();</script>";
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO users (username, password, name, position, department, is_default_pw, auth_level)
        VALUES (:username, :password, :name, :position, :department, 1, 'user')
    ");
    $stmt->bindValue(":username", $username, SQLITE3_TEXT);
    $stmt->bindValue(":password", $default_pw, SQLITE3_TEXT);
    $stmt->bindValue(":name", $name, SQLITE3_TEXT);
    $stmt->bindValue(":position", $position, SQLITE3_TEXT);
    $stmt->bindValue(":department", $department, SQLITE3_TEXT);
    $stmt->execute();

    echo "<script>alert('사용자 생성 완료'); location.href='/admin/dashboard.html';</script>";
    exit;
}
?>
