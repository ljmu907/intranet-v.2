<?php
session_start();
include_once("../../includes/db.php");

// POST 요청 확인
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo "허용되지 않은 접근입니다.";
    exit;
}

// 데이터 수집
$work_id = $_POST["work_id"] ?? null;
$customer_name = $_POST["customer_name"] ?? '';
$manager = $_POST["manager"] ?? '';
$department = $_POST["department"] ?? '';
$cpu = (int)($_POST["cpu"] ?? 0);
$memory = (int)($_POST["memory"] ?? 0);
$ip = $_POST["ip"] ?? '';
$status = $_POST["status"] ?? '';
$payment_method = $_POST["payment_method"] ?? '';
$server_date = $_POST["server_date"] ?? '';
$vat_price = (int)($_POST["vat_price"] ?? 0);
$memo = $_POST["memo"] ?? '';

// 필수 값 체크
if (!$work_id || !$customer_name || !$manager) {
    echo "<script>alert('필수 항목이 누락되었습니다.'); history.back();</script>";
    exit;
}

// DB에 저장
$stmt = $db->prepare("
    INSERT INTO work_entries (
        work_id, customer_name, manager, department,
        cpu, memory, ip, status, payment_method,
        server_date, vat_price, memo
    ) VALUES (
        :work_id, :customer_name, :manager, :department,
        :cpu, :memory, :ip, :status, :payment_method,
        :server_date, :vat_price, :memo
    )
");

$stmt->bindValue(":work_id", $work_id, SQLITE3_INTEGER);
$stmt->bindValue(":customer_name", $customer_name, SQLITE3_TEXT);
$stmt->bindValue(":manager", $manager, SQLITE3_TEXT);
$stmt->bindValue(":department", $department, SQLITE3_TEXT);
$stmt->bindValue(":cpu", $cpu, SQLITE3_INTEGER);
$stmt->bindValue(":memory", $memory, SQLITE3_INTEGER);
$stmt->bindValue(":ip", $ip, SQLITE3_TEXT);
$stmt->bindValue(":status", $status, SQLITE3_TEXT);
$stmt->bindValue(":payment_method", $payment_method, SQLITE3_TEXT);
$stmt->bindValue(":server_date", $server_date, SQLITE3_TEXT);
$stmt->bindValue(":vat_price", $vat_price, SQLITE3_INTEGER);
$stmt->bindValue(":memo", $memo, SQLITE3_TEXT);
$stmt->execute();

// 성공 시 해당 장부 페이지로 이동
header("Location: /works/view.php?id=" . $work_id);
exit;
?>
