<?php
include_once("../../includes/db.php");

$id = $_GET['id'] ?? null;

if (!$id) {
    http_response_code(400);
    echo json_encode(["error" => "ID 누락"]);
    exit;
}

$stmt = $db->prepare("SELECT * FROM work_entries WHERE id = :id");
$stmt->bindValue(":id", $id, SQLITE3_INTEGER);
$res = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if (!$res) {
    http_response_code(404);
    echo json_encode(["error" => "데이터 없음"]);
    exit;
}

header('Content-Type: application/json');
echo json_encode($res);
