<?php
session_start();
include_once("../../includes/db.php");

$is_update = isset($_POST["entry_id"]) && $_POST["entry_id"] !== "";

$fields = [
    "work_id", "customer_name", "manager", "department",
    "cpu", "memory", "storage", "ip", "status",
    "payment_method", "server_date", "vat_price", "memo"
];

// 공통 바인딩 데이터 수집
$data = [];
foreach ($fields as $field) {
    $data[$field] = $_POST[$field] ?? '';
}

// 유효성 검사
if (!$data["work_id"] || !$data["customer_name"] || !$data["manager"]) {
    echo "<script>alert('필수 항목 누락'); history.back();</script>";
    exit;
}

if ($is_update) {
    // 수정
    $stmt = $db->prepare("
        UPDATE work_entries SET
        customer_name = :customer_name,
        manager = :manager,
        department = :department,
        cpu = :cpu,
        memory = :memory,
        storage = :storage,
        ip = :ip,
        status = :status,
        payment_method = :payment_method,
        server_date = :server_date,
        vat_price = :vat_price,
        memo = :memo
        WHERE id = :entry_id
    ");
    foreach ($data as $key => $value) {
        $stmt->bindValue(":$key", $value, is_numeric($value) ? SQLITE3_INTEGER : SQLITE3_TEXT);
    }
    $stmt->bindValue(":entry_id", $_POST["entry_id"], SQLITE3_INTEGER);
    $stmt->execute();
} else {
    // 신규 작성
    $stmt = $db->prepare("
        INSERT INTO work_entries (
            work_id, customer_name, manager, department,
            cpu, memory, storage, ip, status,
            payment_method, server_date, vat_price, memo
        ) VALUES (
            :work_id, :customer_name, :manager, :department,
            :cpu, :memory, :storage, :ip, :status,
            :payment_method, :server_date, :vat_price, :memo
        )
    ");
    foreach ($data as $key => $value) {
        $stmt->bindValue(":$key", $value, is_numeric($value) ? SQLITE3_INTEGER : SQLITE3_TEXT);
    }
    $stmt->execute();
}

// 완료 후 장부 상세로 이동
header("Location: /works/view.php?id=" . $data["work_id"]);
exit;
