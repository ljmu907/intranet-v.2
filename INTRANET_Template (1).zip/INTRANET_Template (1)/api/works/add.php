<?php
session_start();
include_once("../../includes/db.php");

if (!isset($_SESSION['auth_level']) || !in_array($_SESSION['auth_level'], ['admin', 'superadmin'])) {
    http_response_code(403);
    echo "권한이 없습니다.";
    exit;
}

$title = $_POST['title'] ?? '';
$creator = $_SESSION['name'];

if ($title) {
    $stmt = $db->prepare("INSERT INTO works (title, created_by) VALUES (:title, :creator)");
    $stmt->bindValue(':title', $title, SQLITE3_TEXT);
    $stmt->bindValue(':creator', $creator, SQLITE3_TEXT);
    $stmt->execute();
}

header("Location: /works/works.html");
exit;
?>
