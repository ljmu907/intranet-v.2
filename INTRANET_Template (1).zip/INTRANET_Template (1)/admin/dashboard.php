<?php
include_once("../includes/auth.php");
include_once("../includes/db.php");

$username = $_SESSION["username"];
$auth_level = $_SESSION["auth_level"];

// 최근 로그인 로그 가져오기
$logs_stmt = $db->prepare("SELECT * FROM logs ORDER BY created_at DESC LIMIT 10");
$logs = [];
$res = $logs_stmt->execute();
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    $logs[] = $row;
}

// 요약 정보
$total_users = $db->querySingle("SELECT COUNT(*) FROM users");
$total_works = $db->querySingle("SELECT COUNT(*) FROM works");
$today_entries = $db->querySingle("SELECT COUNT(*) FROM work_entries WHERE date(created_at) = date('now')");

?>

<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>관리자 대시보드</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <style>
    .card-box {
      display: flex;
      gap: 20px;
      margin-bottom: 30px;
    }
    .card {
      background: #1f1f2e;
      padding: 20px;
      border-radius: 12px;
      flex: 1;
      text-align: center;
      box-shadow: 0 0 5px rgba(0,0,0,0.2);
    }
    .card h3 {
      font-size: 22px;
      margin-bottom: 10px;
    }
    .log-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 30px;
    }
    .log-table th, .log-table td {
      border: 1px solid #444;
      padding: 10px;
      text-align: left;
    }
  </style>
</head>
<body>
  <?php include("../includes/sidebar.php"); ?>

  <div class="main-content">
    <h1>🛠 관리자 대시보드</h1>

    <div class="card-box">
      <div class="card">
        <h3>전체 유저 수</h3>
        <p><?= $total_users ?>명</p>
      </div>
      <div class="card">
        <h3>전체 장부 수</h3>
        <p><?= $total_works ?>건</p>
      </div>
      <div class="card">
        <h3>오늘 작성된 항목</h3>
        <p><?= $today_entries ?>건</p>
      </div>
    </div>

    <h2>📋 최근 로그인 기록</h2>
    <table class="log-table">
      <thead>
        <tr>
          <th>사용자</th>
          <th>IP</th>
          <th>브라우저 정보</th>
          <th>시간</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($logs as $log): ?>
          <tr>
            <td><?= $log["username"] ?></td>
            <td><?= $log["ip_address"] ?></td>
            <td><?= htmlspecialchars($log["user_agent"]) ?></td>
            <td><?= $log["created_at"] ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
