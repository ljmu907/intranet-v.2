<?php
session_start();
include_once("../includes/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"] ?? '';
    $password = $_POST["password"] ?? '';

    $stmt = $db->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $result = $stmt->execute();
    $user = $result->fetchArray(SQLITE3_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["name"] = $user["name"];
        $_SESSION["auth_level"] = $user["auth_level"];
        $_SESSION["is_default_pw"] = $user["is_default_pw"];

        // 기본 비밀번호라면 비밀번호 변경 페이지로
        if ($user["is_default_pw"]) {
            header("Location: /change_password/change_password.html");
            exit;
        }

        // 정상 로그인 → 대시보드
        header("Location: /admin/dashboard.html");
        exit;
    } else {
        // 로그인 실패
        header("Location: login.html?error=1");
        exit;
    }
}
// 로그인 성공 시
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];

$log_stmt = $db->prepare("INSERT INTO logs (username, ip_address, user_agent) VALUES (:username, :ip, :ua)");
$log_stmt->bindValue(':username', $user["username"], SQLITE3_TEXT);
$log_stmt->bindValue(':ip', $ip, SQLITE3_TEXT);
$log_stmt->bindValue(':ua', $user_agent, SQLITE3_TEXT);
$log_stmt->execute();

?>
