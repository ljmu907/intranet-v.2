<?php
// setup_db.php
$db_path = __DIR__ . '/data/intranet.db';

// 이미 DB가 있으면 중복 생성 막기
if (file_exists($db_path)) {
    die("❌ DB가 이미 존재합니다. 초기화하려면 수동 삭제 후 실행하세요.");
}

$db = new SQLite3($db_path);

// users 테이블 생성
$db->exec("
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        position TEXT NOT NULL,
        department TEXT NOT NULL,
        is_default_pw INTEGER DEFAULT 1,
        auth_level TEXT DEFAULT 'user'
    )
");

// 최고 관리자 계정 추가
$default_id = 'devljs';
$default_pw = password_hash('code!0728', PASSWORD_DEFAULT);

$db->exec("
    INSERT INTO users (username, password, name, position, department, is_default_pw, auth_level)
    VALUES ('$default_id', '$default_pw', '관리자', '최고관리자', '개발팀', 0, 'superadmin')
");

echo "✅ DB 생성 완료 및 관리자 계정 등록 완료!";


$db->exec("
  CREATE TABLE IF NOT EXISTS works (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    created_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
");

$db->exec("
  CREATE TABLE IF NOT EXISTS work_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    work_id INTEGER,
    customer_name TEXT,
    manager TEXT,
    department TEXT,
    cpu INTEGER,
    memory INTEGER,
    ip TEXT,
    status TEXT,
    payment_method TEXT,
    server_date TEXT,
    vat_price INTEGER,
    memo TEXT,
    FOREIGN KEY(work_id) REFERENCES works(id)
)
");
$db->exec("
CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
");


?>