<?php
include_once("includes/auth.php");
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>인트라넷</title>
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
  <h1>환영합니다, <?= $_SESSION["name"] ?>님</h1>
  <p>직책: <?= $_SESSION["position"] ?> / 부서: <?= $_SESSION["department"] ?></p>
  <a href="/logout.php">로그아웃</a>
</body>
</html>
