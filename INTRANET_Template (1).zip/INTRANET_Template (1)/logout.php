<?php
// logout.php
session_start();
session_unset();   // 모든 세션 변수 제거
session_destroy(); // 세션 자체 삭제
header("Location: /login/login.html");
exit;
