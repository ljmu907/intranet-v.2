<?php
include_once("../includes/auth.php");
include_once("../includes/db.php");

$work_id = $_GET["id"] ?? null;
if (!$work_id) {
    echo "장부 ID가 없습니다.";
    exit;
}

$stmt = $db->prepare("SELECT * FROM works WHERE id = :id");
$stmt->bindValue(":id", $work_id, SQLITE3_INTEGER);
$result = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
if (!$result) {
    echo "존재하지 않는 장부입니다.";
    exit;
}
$title = $result["title"];

// 항목 리스트
$entries = [];
$entry_stmt = $db->prepare("SELECT * FROM work_entries WHERE work_id = :id ORDER BY id DESC");
$entry_stmt->bindValue(":id", $work_id, SQLITE3_INTEGER);
$res = $entry_stmt->execute();
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    $entries[] = $row;
}

// 차트용 데이터
$total_sales = $db->querySingle("SELECT SUM(vat_price) FROM work_entries WHERE work_id = $work_id");

$dept_stmt = $db->prepare("
    SELECT department, SUM(vat_price) as total
    FROM work_entries
    WHERE work_id = :id
    GROUP BY department
");
$dept_stmt->bindValue(":id", $work_id, SQLITE3_INTEGER);
$dept_res = $dept_stmt->execute();

$dept_sales = [];
while ($row = $dept_res->fetchArray(SQLITE3_ASSOC)) {
    $dept_sales[] = $row;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($title) ?></title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 30px;
    }
    th, td {
      border: 1px solid #333;
      padding: 10px;
      text-align: left;
    }
    .write-btn {
      margin-top: 20px;
      background: #00c3ff;
      color: black;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <?php include("../includes/sidebar.php"); ?>

  <div class="main-content">
    <h2>📘 <?= htmlspecialchars($title) ?></h2>
    <a class="write-btn" href="/works/form.html?work_id=<?= $work_id ?>">+ 신규 작성</a>

    <!-- 차트 영역 -->
    <div id="total_chart" style="width: 100%; height: 300px;"></div>
    <div id="dept_chart" style="width: 100%; height: 300px;"></div>

    <!-- 테이블 -->
    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>고객명</th>
          <th>영업 담당자</th>
          <th>부서</th>
          <th>CPU</th>
          <th>메모리</th>
          <th>IP</th>
          <th>상태</th>
          <th>결제</th>
          <th>서버일</th>
          <th>금액</th>
          <th>비고</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($entries as $entry): ?>
          <tr>
            <td><?= $entry["id"] ?></td>
            <td><?= htmlspecialchars($entry["customer_name"]) ?></td>
            <td><?= htmlspecialchars($entry["manager"]) ?></td>
            <td><?= htmlspecialchars($entry["department"]) ?></td>
            <td><?= $entry["cpu"] ?></td>
            <td><?= $entry["memory"] ?></td>
            <td><?= $entry["ip"] ?></td>
            <td><?= htmlspecialchars($entry["status"]) ?></td>
            <td><?= htmlspecialchars($entry["payment_method"]) ?></td>
            <td><?= $entry["server_date"] ?></td>
            <td><?= number_format($entry["vat_price"]) ?>원</td>
            <td><?= htmlspecialchars($entry["memo"]) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <script>
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawCharts);

    function drawCharts() {
      const totalData = google.visualization.arrayToDataTable([
        ['항목', '금액'],
        ['총 매출', <?= $total_sales ?: 0 ?>]
      ]);
      const totalChart = new google.visualization.PieChart(document.getElementById('total_chart'));
      totalChart.draw(totalData, {
        title: '총 매출 (VAT 포함)',
        pieHole: 0.4,
        colors: ['#00c3ff']
      });

      const deptData = google.visualization.arrayToDataTable([
        ['부서', '매출'],
        <?php foreach ($dept_sales as $d): ?>
          ['<?= $d["department"] ?>', <?= $d["total"] ?>],
        <?php endforeach; ?>
      ]);
      const deptChart = new google.visualization.PieChart(document.getElementById('dept_chart'));
      deptChart.draw(deptData, {
        title: '부서별 매출 분포',
        is3D: true
      });
    }
  </script>
</body>
</html>
