<?php
include_once("../includes/auth.php");
include_once("../includes/db.php");

$stmt = $db->query("SELECT * FROM works ORDER BY created_at DESC");
$works = [];
while ($row = $stmt->fetchArray(SQLITE3_ASSOC)) {
    $works[] = $row;
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>Works</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <style>
    .works-container { padding: 40px; display: flex; flex-wrap: wrap; gap: 20px; }
    .work-card {
      width: 220px; padding: 20px;
      background: #1f1f2e; border-radius: 12px; color: white;
      box-shadow: 0 0 5px rgba(0,0,0,0.2); text-align: center;
      transition: 0.3s;
    }
    .work-card:hover { background: #2b2b3e; cursor: pointer; }
    .work-card a { color: inherit; text-decoration: none; display: block; }
    .create-btn {
      margin-bottom: 30px;
      padding: 10px 20px;
      background: #00c3ff; color: black;
      border: none; border-radius: 8px;
      font-weight: bold; cursor: pointer;
    }
  </style>
</head>
<body>
  <?php include("../includes/sidebar.php"); ?>

  <div class="main-content">
    <h1>📊 Works Home</h1>

    <?php if ($_SESSION['auth_level'] === 'superadmin' || $_SESSION['auth_level'] === 'admin'): ?>
      <form action="/api/works/add.php" method="POST">
        <input type="text" name="title" placeholder="예: 2025년 6월 가맹점 일별 매출 관리" required>
        <button type="submit" class="create-btn">장부 생성</button>
      </form>
    <?php endif; ?>

    <div class="works-container">
      <?php foreach ($works as $work): ?>
        <div class="work-card">
          <a href="/works/view.php?id=<?= $work['id'] ?>">
            📈 <?= htmlspecialchars($work['title']) ?>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</body>
</html>
