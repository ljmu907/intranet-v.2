<?php
session_start();

// 로그인 안 한 경우 login 페이지로 이동
if (!isset($_SESSION["user_id"])) {
    header("Location: /login/login.html");
    exit;
}
?>
