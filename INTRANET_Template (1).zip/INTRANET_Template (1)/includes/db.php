<?php
// includes/db.php
$db = new SQLite3(__DIR__ . '/../data/intranet.db');
