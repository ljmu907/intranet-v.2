<?php
session_start();
?>

<aside class="sidebar">
  <div class="sidebar-header">
    <h2>인트라넷</h2>
    <p><?= $_SESSION['name'] ?> (<?= $_SESSION['position'] ?>)</p>
  </div>
  <nav class="sidebar-nav">
    <ul>
      <li><a href="/admin/dashboard.html">🏠 대시보드</a></li>
      <li><a href="/works/works.html">🕒 근무기록</a></li>
      <li><a href="/board/board.html">📢 게시판</a></li>
      <li><a href="/mypage/index.html">👤 내 정보</a></li>
      <li><a href="/logout.php">🚪 로그아웃</a></li>
    </ul>
  </nav>
</aside>
