<?php
function log_login($username) {
    global $db;
    $ip = $_SERVER['REMOTE_ADDR'];
    $ua = $_SERVER['HTTP_USER_AGENT'];
    
    $stmt = $db->prepare("INSERT INTO logs (username, ip_address, user_agent) VALUES (:username, :ip, :ua)");
    $stmt->bindValue(":username", $username, SQLITE3_TEXT);
    $stmt->bindValue(":ip", $ip, SQLITE3_TEXT);
    $stmt->bindValue(":ua", $ua, SQLITE3_TEXT);
    $stmt->execute();
}
