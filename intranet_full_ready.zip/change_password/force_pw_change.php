<?php
session_start();
include_once("../includes/db.php");

if (!isset($_SESSION["username"])) {
    header("Location: /login/login.html");
    exit;
}
$new = $_POST["new_pw"] ?? '';
$confirm = $_POST["confirm_pw"] ?? '';
if ($new !== $confirm || strlen($new) < 4) {
    die("비밀번호 불일치 또는 너무 짧음");
}
$hash = password_hash($new, PASSWORD_DEFAULT);
$stmt = $db->prepare("UPDATE users SET password = :pw, is_default_pw = 0 WHERE username = :username");
$stmt->bindValue(":pw", $hash, SQLITE3_TEXT);
$stmt->bindValue(":username", $_SESSION["username"], SQLITE3_TEXT);
$stmt->execute();
header("Location: /works/works.php");
?>