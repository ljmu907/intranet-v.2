<?php
session_start();
include_once("../../includes/db.php");
if (!isset($_SESSION["username"])) exit("로그인 필요");
$title = $_POST["title"] ?? '';
$stmt = $db->prepare("INSERT INTO works (title, created_by) VALUES (:t, :u)");
$stmt->bindValue(":t", $title, SQLITE3_TEXT);
$stmt->bindValue(":u", $_SESSION["username"], SQLITE3_TEXT);
$stmt->execute();
header("Location: /works/works.php");
?>