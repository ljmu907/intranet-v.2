<?php
session_start();
include_once("../includes/db.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"] ?? '';
    $password = $_POST["password"] ?? '';

    $stmt = $db->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindValue(":username", $username, SQLITE3_TEXT);
    $res = $stmt->execute();
    $user = $res->fetchArray(SQLITE3_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["username"] = $user["username"];
        $_SESSION["name"] = $user["name"];
        $_SESSION["auth_level"] = $user["auth_level"];
        $_SESSION["is_default_pw"] = $user["is_default_pw"];

        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        $log_stmt = $db->prepare("INSERT INTO logs (username, ip_address, user_agent) VALUES (:username, :ip, :ua)");
        $log_stmt->bindValue(":username", $user["username"], SQLITE3_TEXT);
        $log_stmt->bindValue(":ip", $ip, SQLITE3_TEXT);
        $log_stmt->bindValue(":ua", $ua, SQLITE3_TEXT);
        $log_stmt->execute();

        if ($user["is_default_pw"]) {
            header("Location: /change_password/change_password.html");
            exit;
        }
        header("Location: /works/works.php");
        exit;
    } else {
        header("Location: login.html?error=1");
        exit;
    }
}
?>