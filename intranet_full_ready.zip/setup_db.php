<?php
$db = new SQLite3(__DIR__.'/data/intranet.db');
$db->exec("CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY, username TEXT, password TEXT, name TEXT,
  position TEXT, department TEXT, is_default_pw INTEGER, auth_level TEXT)");
$pw = password_hash("code!0728", PASSWORD_DEFAULT);
$db->exec("INSERT OR IGNORE INTO users (username, password, name, position, department, is_default_pw, auth_level)
VALUES ('devljs', '$pw', '관리자', '최고관리자', '개발팀', 0, 'superadmin')");
$db->exec("CREATE TABLE IF NOT EXISTS works (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, created_by TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS work_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT, work_id INTEGER, customer_name TEXT, manager TEXT,
  department TEXT, cpu INTEGER, memory INTEGER, ip TEXT, status TEXT,
  payment_method TEXT, server_date TEXT, vat_price INTEGER, memo TEXT)");
$db->exec("CREATE TABLE IF NOT EXISTS logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, ip_address TEXT, user_agent TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
echo '✅ DB 준비 완료';
?>