<?php
session_start();
include_once("../includes/db.php");
if (!isset($_SESSION["username"])) { header("Location: /login/login.html"); exit; }

$stmt = $db->query("SELECT * FROM works ORDER BY created_at DESC");
$works = [];
while ($r = $stmt->fetchArray(SQLITE3_ASSOC)) $works[] = $r;
?>
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="UTF-8"><title>장부</title></head>
<body>
  <h1>장부 목록</h1>
  <form action="/api/works/add.php" method="POST">
    <input type="text" name="title" placeholder="장부 제목" required>
    <button type="submit">장부 생성</button>
  </form>
  <ul>
    <?php foreach ($works as $w): ?>
      <li><a href="/works/view.php?id=<?= $w['id'] ?>"><?= $w['title'] ?></a></li>
    <?php endforeach; ?>
  </ul>
</body>
</html>